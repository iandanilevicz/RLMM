#' @noRd
initial = function(y, x, d, q, l, nq, cor, tol, loss, c=1.34){
  xnew = x
  q1   = stats::quantile(x[,d], 0.15)
  q3   = stats::quantile(x[,d], 0.85)
  xnew[,d] = ifelse(x[,d]<q1 | x[,d]>q3, NA, x[,d]) 
  m0    = stats::lm(y ~ -1+x)
  out   = summary(m0)
  SD    = as.vector(out$coefficients[,2])
  res   = as.vector(m0$residuals)
  sig0  = stats::sd(res)
  beta  = as.vector(m0$coefficients) 
  betal  = beta - 1.96*SD
  betau  = beta + 1.96*SD
  sigma  = rep(0.7 * sig0, q+1)  
  sigmal = rep(tol, q+1)
  sigmau = rep(2 * sig0, q+1) 
  if(cor == "Ind"){
    cor    = stats::runif(l,tol,0.1)
    corl   = rep(tol, l)
    coru   = rep(1-tol, l)
    theta = c(beta, sigma, cor)
    lower = c(betal, sigmal, corl)
    upper = c(betau, sigmau, coru)
  } else {
    cor    = stats::runif(l+1,tol,0.1)
    corl   = rep(tol, l+1)
    coru   = rep(1-tol, l+1)
    theta = c(beta, sigma[1], cor[1], sigma[-1], cor[-1])
    lower = c(betal, sigmal[1], corl[1], sigmal[-1], corl[-1])
    upper = c(betau, sigmau[1], coru[1], sigmau[-1], coru[-1])
  }
  return(list(theta=theta, lower=lower, upper=upper))	
}

#' @noRd
opt = function(n, N, d, q, l, y, x, z, nj, tol, c, theta, lower, upper, loss, cor, weight){
  if(weight==TRUE){
    wi = hhat(x)
    if(loss == "LS"){
      if(cor=="Ind"){
        Opt = stats::optim(par=theta, fn = Eta_ind_abs_w, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, w=wi,
                    control=list(fnscale=-1))
      }else{
        Opt = stats::optim(par=theta, fn = Eta_ar1_abs_w, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, w=wi,    
                    control=list(fnscale=-1))
      }
    } 
    if(loss == "Huber"){
      if(cor=="Ind"){
        Opt = stats::optim(par=theta, fn = Eta_ind_huber_w,  method = "L-BFGS-B", hessian = TRUE,
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c, w=wi,    
                    control=list(fnscale=-1))
      }
      if(cor=="AR1"){
        Opt = stats::optim(par=theta, fn = Eta_ar1_huber_w, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c, w=wi,   
                    control=list(fnscale=-1))
      }
    }
    if(loss == "Tukey"){
      if(cor=="Ind"){
        Opt = stats::optim(par=theta, fn = Eta_ind_tukey_w, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c, w=wi,   
                    control=list(fnscale=-1))
      }
      if(cor=="AR1"){
        Opt = stats::optim(par=theta, fn = Eta_ar1_tukey_w, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c, w=wi,    
                    control=list(fnscale=-1))
      }
    }  
  }else{
    if(loss == "LS"){
      if(cor=="Ind"){
        Opt = stats::optim(par=theta, fn = Eta_ind_abs, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol,
                    control=list(fnscale=-1))
      }else{
        Opt = stats::optim(par=theta, fn = Eta_ar1_abs, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol,    
                    control=list(fnscale=-1))
      }
    } 
    if(loss == "Huber"){
      if(cor=="Ind"){
        Opt = stats::optim(par=theta, fn = Eta_ind_huber,  method = "L-BFGS-B", hessian = TRUE,
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c,    
                    control=list(fnscale=-1))
      }
      if(cor=="AR1"){
        Opt = stats::optim(par=theta, fn = Eta_ar1_huber, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c,    
                    control=list(fnscale=-1))
      }
    }
    if(loss == "Tukey"){
      if(cor=="Ind"){
        Opt = stats::optim(par=theta, fn = Eta_ind_tukey, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c,   
                    control=list(fnscale=-1))
      }
      if(cor=="AR1"){
        Opt = stats::optim(par=theta, fn = Eta_ar1_tukey, method = "L-BFGS-B", hessian = TRUE, 
                    lower = lower, upper = upper,
                    n=n, N=N, d=d, q=q, l=l, y=y, x=x, z=z, nj=nj, tol=tol, c=c,    
                    control=list(fnscale=-1))
      }
    }
  } 
  return(Opt)
}

#' @noRd
organizer = function(y, x, z, id){
  n = max(id)
  N = length(y)
  d = dim(x)[2]
  q  = ifelse(is.null(dim(z)[2]), 1, dim(z)[2])
  ynew = NULL
  xnew = NULL
  znew = NULL
  nj   = NULL 
  for(j in 1:n){
    n0 = length(ynew)
    for(i in 1:N){
      if(id[i] == j){
        if( any(c(is.null(y[i]), is.null(x[i,]), is.null(z[i,])))){
        } else {
          if( any(c(is.na(y[i]), is.na(x[i,]), is.na(z[i,])))){
          } else {
            ynew = c(ynew, y[i])
            xnew = matrix(rbind(xnew, x[i,]), ncol=d)
            znew = matrix(rbind(znew, z[i,]), ncol=q)
          }  
        }  
      }
    }
    n1 = length(ynew) - n0
    if(n1>0) nj = rbind(nj, n1)  
  }
  y = as.vector(ynew)
  x = as.matrix(xnew)
  z = as.matrix(znew)
  nj = as.vector(nj)
  return(list(y=y,x=x,z=z,nj=nj))
}

#' @noRd
hhat = function(x){
  H = x %*% (MASS::ginv(t(x) %*% x)) %*% t(x)
  hi = diag(H)
  wi = as.vector(sqrt(1-hi))
  return(wi)
}

#' Robust linear model
#'
#' Estimate parameters of a robust linear mixed models. 
#'
#' @param y      Numeric vector, outcome.
#' @param x      Numeric matrix, covariates
#' @param z      Numeric vector or matrix, a vector of 1's for random intercepts, a vector of one covariate for random slopes.
#' @param subj   Numeric vector, identifies the unit to which the observation belongs.
#' @param cor    Factor, "Ind" for independent residuals, "AR1" for autoregressive first order residuals.
#' @param loss   Factor, "LS" least squared loss function, "Huber" loss function or "Tukey" loss function.
#' @param c      Numeric, positive real number, common choices are 1.345 for Huber and 4.685 for Tukey.
#' @param weight Factor, if TRUE uses the Cantoni's weigths, if FALSE does not. 
#' @param tol    Numeric scalar, internal value, small value.
#' 
#' @return beta        Numeric vector, exploratory variables' coefficients.
#' @return sigma       Numeric, standard deviation.
#' @return Psi         Numeric matrix, covariance structure.
#' @return phi         Numeric, scalar of covariance structure.
#' @return SE          Numeric vector, exploratory variables' standard errors.
#' @return loss        Factor, "LS" least squared loss function, "Huber" loss function or "Tukey" loss function.
#' @return cor         Factor, "Ind" for independent residuals, "AR1" for autoregressive first order residuals.
#' 
#' @importFrom MASS stats
#' @import Rcpp RcppArmadillo
#' 
#' @examples 
#' n = 10
#' m = 5
#' d = 4
#' N = n*m
#' x = matrix(rnorm(d*N), ncol=d, nrow=N)
#' subj = rep(1:n, each=m)
#' gamma = rnorm(n)
#' z = rep(1,N)
#' beta = rnorm(d)
#' eps = rnorm(N)
#' y = as.vector(x %*% beta + rep(gamma, each=m) + eps)
#' m1 = roblim(y, x, z, subj, cor="Ind", loss="Huber", c=1.345, weight = FALSE) 
#' m1
#' 
#' @references Danilevicz, I.M., Bondon, P., Reisen, V.A., Serpa, F.S. (2022), 
#' "A longitudinal study of the influence of air pollutants on respiratory health. A robust multivariate approach".
#' Journal, vol number pages.  
#' 
#' Gill, P.S. (2000), "A robust mixed linear model analysis for longitudinal data", Stat. Med., 19: 975-987.    
#'
#' Cantoni, E., Ronchetti, E. (2001), "Robust Inference for Generalized Linear Models", J. Am. Stat. Assoc., 96 (455): 1022-1030.
#'      
#' @export
roblim = function(y, x, z, subj, cor="Ind", loss="Huber", c=1.345, weight=TRUE, tol=1e-4){
  z     = matrix(z)
  d     = dim(x)[2]
  q     =  ifelse(is.null(dim(z)[2]), 1, dim(z)[2])
  l     = ifelse(q>1, sum(q-(1:(q-1))), 0)
  nq    = (q * (1 + q)/2)
  npar  = d + 1 + (q * (1 + q)/2)
  set   = organizer(y, x, z, subj)
  y     = as.vector(set$y)
  x     = as.matrix(set$x) 
  z     = as.matrix(set$z) 
  nj    = as.vector(set$nj)
  N     = dim(x)[1]
  n     = length(nj)
  ZB    = rep(0, N)
  SE    = rep(1, d)
  init  = initial(y, x, d, q, l, nq, cor, tol, loss, c)
  theta = init$theta
  lower = init$lower
  upper = init$upper 
  Opt   = opt(n, N, d, q, l, y, x, z, nj, tol, c, theta, lower, upper, loss, cor, weight)
  theta = Opt$par
  K2    = k2(n, N, d, q, l, y, x, z, nj, tol, c, theta, loss, cor)
  SE    = sqrt(K2) * Sd(as.matrix(-Opt$hessian[1:d,1:d]), tol) 
  beta  = theta[1:d] 
  sigma = theta[d+1]
  phi   = ifelse(cor == "AR1", theta[d+2], 0)
  if(cor == "AR1") Psi = theta2cov(theta[(d+3):(d+2+q+l)], q) 
  if(cor == "Ind") Psi = theta2cov(theta[(d+2):(d+1+q+l)], q)   
  table = data.frame(beta, SE, beta - (1.96 * SE), beta + (1.96 * SE), beta/SE, 2 * stats::pnorm(abs(beta/SE), lower.tail = F))
  rownames(table) = paste("beta", 1:d)
  colnames(table) = c("Estimate", "Std. Error", "Inf CI95%", "Sup CI95%", "z value", "Pr(>|z|)")
  obj = list(beta = beta, sigma = sigma, Psi=Psi, phi=phi, SE = SE, table = table, loss=loss, cor=cor)
  class(obj) = "RLMM"
  return(obj)
} 

#' @noRd
print.RLMM = function(obj){
  if(obj$cor == "Ind"){
    if(obj$loss=="LS"){
      cat("\n Linear mixed model (LS) - Independent \n \n")
      base::print(obj$table)
      invisible(obj)    
    }
    if(obj$loss=="Huber"){
      cat("\n Robust linear mixed model (Huber) - Independent \n \n")
      base::print(obj$table)
      invisible(obj)    
    }
    if(obj$loss=="Tukey"){
      cat("\n Robust linear mixed model (Tukey) - Independent \n \n")
      base::print(obj$table)
      invisible(obj)    
    }
  }else{
    if(obj$loss=="LS"){
      cat("\n Linear mixed model (LS) - AR(1) \n \n")
      base::print(obj$table)
      invisible(obj)    
    }
    if(obj$loss=="Huber"){
      cat("\n Robust linear mixed model (Huber) - AR(1) \n \n")
      base::print(obj$table)
      invisible(obj)    
    }
    if(obj$loss=="Tukey"){
      cat("\n Robust linear mixed model (Tukey) - AR(1) \n \n")
      base::print(obj$table)
      invisible(obj)    
    }    
  }  
}


