#include <RcppArmadillo.h>
// [[Rcpp::depends(RcppArmadillo)]]

using namespace Rcpp;

double log_det(arma::mat X, double tol){
  double ldet;
  ldet = arma::det(X);
  if(ldet > tol){
    ldet = log(ldet);
  }else{
      ldet = log(tol);
  }
  return(ldet);
}

arma::mat diag_s(double a, int n){
  arma::mat M(n,n);
  M = a * arma::eye(n,n);
  return(M);
}

arma::mat diag_v(arma::vec a, int n){
  arma::mat M(n,n);
  M = arma::eye(n,n);
  for(int i = 0; i < n; ++i){
    for(int j = 0; j < n; ++j){
      if(i == j){
        M(i,j) = a(i);
      }  
    }  
  }
  return(M);
}

arma::mat diag_sand(arma::mat X, double tol){
  int n = X.n_rows;
  arma::mat D(n,n);
  arma::vec u(n);
  D = X;
  u = arma::randu(n);
  for(int i = 0; i < n; ++i){
    u(i) = 1 + (u(i)-0.5)*tol;
    D(i,i) = X(i,i) * u(i) ;
  }  
  return(D);
}

arma::mat as_sym(arma::mat X){
  int n = X.n_rows;
  arma::mat D(n,n);
  D = X;
  for(int i = 0; i < n; ++i){
    for(int j = 0; j < n; ++j){
      if(i < j){
        D(j,i) = X(i,j);
      }  
    }  
  }
  return(D);
}

double abss(double x){
  x = pow(pow(x,2),0.5);
  return(x);
}

double count_c(arma::vec x, double c){
  int n = x.n_elem;
  double a = 0;
  arma::vec y(n);
  for(int i=0; i<n; i++){
    if(x(i)<c) y(i) = 1;
    else  y(i) = 0;
  }
  a = arma::accu(y);
  return(a);
}

double sum_ijk(arma::mat x, int i, int j){
  int k = j - i;
  int n = x.n_rows;
  double count = 0;
  if( j > n ){
    return(count);
  } else if(k > 1){
    for(k = i+1; k<j; k++){
      count = count + x(i,k) * x(k,j); 
    }  
  }
  return(count);
}

arma::mat Sqrtm(arma::mat X){
  int n = X.n_rows;
  int i = 0; 
  int j = 0;
  arma::mat U(n,n), S(n,n), R(n,n);
  schur(U,S,X);
  R.zeros(); 
  for(i = 0; i<n; i++){
    R(i,i) = pow(pow(S(i,i), 2), 0.25); 
  }
  for(j = 1; j<n; j++){
    for(i = j-1; i>-1; i--){
      if(i < j) R(i,j) = (S(i,j) - sum_ijk(S, i, j))/(R(i,i) + R(j,j));           
    }
  }
  return(U*R*trans(U)); 
}  

arma::mat Inv_Sqrt(arma::mat X, double tol){
  int n = X.n_rows;
  arma::mat S(n,n);
  arma::mat I(n,n);
  S.zeros();
  I.zeros();
  X = as_sym(X);
  try{
    I = arma::inv(X);
    S = Sqrtm(I);
    return(S);
  }catch(...){
    S = Sqrtm(X);
    I = arma::inv(S);
    return(I);
  }
}

// [[Rcpp::export(Sd)]]
arma::vec Sd(arma::mat X, double tol){
  int n = X.n_rows;
  arma::vec y(n);
  arma::mat I(n,n);
  X = as_sym(X);
  try{
    I = arma::inv(X);
  }catch(...){
    X = diag_sand(X, 0.01);
    I = arma::inv(X);
  }
  for(int i = 0; i < n; ++i){
      y(i) = I(i,i);
  }
  y = arma::abs(y);
  y = arma::sqrt(y);
  return(y);
}

double eta_trunc(double k1, double sum1, double sum2, double tol){
  double eta = 0;
  double Tol = 1/tol;
  if(k1 < -Tol)     k1 = -Tol;
  else if(k1 > Tol) k1 = Tol;
  if(sum1 < -Tol)     sum1 = -Tol;
  else if(sum1 > Tol) sum1 = Tol;
  if(sum2 < -Tol)     sum2 = -Tol;
  else if(sum2 > Tol) sum2 = Tol;
  eta = -0.5*k1*sum1 -sum2;    
  if(eta < -Tol)     eta = -Tol;
  else if(eta > Tol) eta = Tol;
  return(eta);
} 

arma::vec rho_abs(arma::vec x) {
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    y(i) = 0.5*pow(x(i),2);
  }
  return(y);
}

arma::vec psi_abs(arma::vec x){
  return(x);
} 

arma::vec deriv_psi_abs(arma::vec x){
  int n = x.n_elem;
  arma::vec y(n); 
  return(y.ones(n));
}

arma::vec rho_huber(arma::vec x, double c){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(c < x(i)){
      y(i) = (c*x(i)-pow(c,2)/2);
    } else if (c >= x(i) && -c  < x(i)){
      y(i) = 0.5*pow(x(i),2);
    } else {
      y(i) = (-c*x(i) -0.5*pow(c,2));
    }
  }
  return(y);
} 

arma::vec psi_huber(arma::vec x, double c){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(c < x(i)){
      y(i) = c;
    } else if (c >= x(i) && -c  < x(i)){
      y(i) = x(i);
    } else {
      y(i) = -c;
    }
  }
  return(y);
} 

arma::vec deriv_psi_huber(arma::vec x, double c){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(c < x(i)){
      y(i) = 0;
    } else if (c >= x(i) && -c  < x(i)){
      y(i) = 1;
    } else {
      y(i) = 0;
    }
  }
  return(y);
} 

arma::vec rho_tukey(arma::vec x, double c){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(c < x(i)){
      y(i) = pow(c,2)/6;
    } else if (c >= x(i) && -c  < x(i)){
      y(i) = pow(c,2)/6 *(1-pow(1-pow(x(i)/c, 2), 3));
    } else {
      y(i) = pow(c,2)/6;
    }
  }
  return(y);
} 

arma::vec psi_tukey(arma::vec x, double c){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(c < x(i)){
      y(i) = 0;
    } else if (c >= x(i) && -c  < x(i)){
      y(i) = x(i)*pow(1-pow(x(i)/c, 2),2);
    } else {
      y(i) = 0;
    }
  }
  return(y);
} 

arma::vec deriv_psi_tukey(arma::vec x, double c){
  int n = x.n_elem;
  arma::vec y(n); 
  for(int i = 0; i < n; ++i){
    if(c < x(i)){
      y(i) = 0;
    } else if (c >= x(i) && -c  < x(i)){
      y(i) = ((5*pow(x(i),4)/pow(c,4)) - (6*pow(x(i),2)/pow(c,2) +1));
    } else {
      y(i) = 0;
    }
  }
  return(y);
} 

// [[Rcpp::export(theta2cov)]]
arma::mat theta2cov(arma::vec theta, int q){
  arma::mat covm(q,q);
  int count = -1;
  covm = diag_v(theta, q);
  for(int i = 0; i < q; ++i){
    for(int j = 0; j < q; ++j){
      if(i > j){
        count = count + 1;
        if(theta(i)*theta(j)>0){
          covm(i,j) = pow(theta(i)*theta(j), 0.5)*theta(q+count);
          covm(j,i) = covm(i,j); 
        } else {
          covm(i,j) = 0;
          covm(j,i) = 0;   
        }
      }
    }
  } 
  return(covm);
}

arma::mat ar1(double a, int n){
  arma::mat M(n,n);
  M = diag_s(1, n);
  for(int i = 0; i < n; ++i){
    for(int j = 0; j < n; ++j){
        M(i,j) = pow(a, abss(i-j));
    }	
  }
  return(M);	
}

arma::mat ar0(double a, int n){
  arma::mat M(n,n);
  M = diag_s(1, n);
  for(int i = 0; i < n; ++i){
    for(int j = 0; j < n; ++j){
      M(i,j) = abss(i-j) * pow(a, abss(i-j)-1);
    }	
  }
  return(M);	
}

arma::vec fill_v(int a, int b, arma::vec x){
  int n = b - a + 1;
  arma::vec y(n);
  for(int i=0; i<n; i++){
    y(i) = x[i+a-1];
  }
  return(y);
}

arma::mat fill_M(int r1, int rn, int c1, int cn, arma::mat X){
  int n1 = rn - r1 + 1;
  int n2 = cn - c1 + 1;
  arma::mat Y(n1, n2);
  for(int i=0; i<n1; i++){
    for(int j=0; j<n2; j++){  
      Y(i,j) = X(i+r1-1, j+c1-1);
    }  
  }
  return(Y);
}

// [[Rcpp::export(Eta_ind_abs)]]
double Eta_ind_abs(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                     arma::vec theta){
  double k1 = 1;
  double sum1 = 0;
  double sum2 = 0; 
  double eta  = 0;
  double ldet = 0;
  int a = 0;
  int b = 0;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_abs(res1);
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  eta = eta_trunc(k1, sum1, sum2, tol); 
  return(eta);  
}

// [[Rcpp::export(Eta_ar1_abs)]]
double Eta_ar1_abs(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                   arma::vec theta){
  double k1 = 1;
  double sum1 = 0;
  double sum2 = 0; 
  double eta  = 0;
  double ldet = 0;
  double thetad = pow(theta(d),2);
  int a = 0;
  int b = 0;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+3), (d+3+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  (thetad * ar1(theta(d+1), nk));
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_abs(res1);
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  eta = eta_trunc(k1, sum1, sum2, tol); 
  return(eta);  
}

// [[Rcpp::export(Eta_ind_huber)]]
double Eta_ind_huber(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                     double c, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_huber(res1, c);
    res4 = deriv_psi_huber(res1, c);
    k1   = k1 + accu(res4); 
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

// [[Rcpp::export(Eta_ar1_huber)]]
double Eta_ar1_huber(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                       double c, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  double thetad = pow(theta(d),2);
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+3), (d+3+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  (thetad * ar1(theta(d+1), nk));
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_huber(res1, c);
    res4 = deriv_psi_huber(res1, c);
    k1   = k1 + accu(res4);
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

// [[Rcpp::export(Eta_ind_tukey)]]
double Eta_ind_tukey(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                       double c, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_tukey(res1, c);
    res4 = deriv_psi_tukey(res1, c);
    k1   = k1 + accu(res4); 
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

// [[Rcpp::export(Eta_ar1_tukey)]]
double Eta_ar1_tukey(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                       double c, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  double thetad = pow(theta(d),2);
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+3), (d+3+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  (thetad * ar1(theta(d+1), nk));
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_tukey(res1, c);
    res4 = deriv_psi_tukey(res1, c);
    k1   = k1 + accu(res4); 
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

// [[Rcpp::export(aic)]]
double aic(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, 
           arma::vec beta, double sigma, double phi, arma::mat Psi, std::string cor, double tol){
  int P = 0;
  double AIC =0;
  double sum1 = 0;
  double pi = 3.14159265359; 
  arma::vec res(N);
  res.zeros(); 
  double ldet = 0;
  int a = 0;
  int b = 0;
  int nk = nj.max();
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::mat R1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  if(cor=="Ind") P = d + 1 + q + l;
  else           P = d + 2 + q + l; 
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(cor=="Ind")  R1 = diag_s(pow(sigma,2), nk);
    else            R1 = pow(sigma,2) * ar1(phi, nk); 
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = z1 * Psi * trans(z1) + R1;
    ldet = ldet + log_det(V1, tol);
    P1   = Inv_Sqrt(V1, tol);
    res0 = y1 - (x1 * beta); 
    res1 = P1 * res0;
    sum1 = sum1 + accu(res1);
  }
  AIC = (ldet + 2*sum1  + 2*P + d*n*log(2*pi))/N; 
  return(AIC);
}

// [[Rcpp::export]]
double k2(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, 
          double tol, double c, arma::vec theta, std::string loss, std::string cor){
  double k1   = 0;
  double k2   = 0;
  double k3   = 0;
  //double ldet = 0;  
  int a = 0;
  int b = 0;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
 // arma::vec res2(nk); 
  arma::vec res3(nk);
  arma::vec res4(nk);  
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);
  if(cor == "AR1")  theta2 = fill_v((d+3), (d+3+q+l), theta);
  else              theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);  
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0)  a = 1,      b = nk;  
    else      a = b + 1,  b = b + nk;
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    if(cor == "AR1")  V1   = z1 * D * trans(z1) +  pow(theta(d),2) * ar1(theta(d+1), nk);
    else              V1   = z1 * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    //ldet = log_det(V1, tol);
    P1   = Inv_Sqrt(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    if(loss == "LS"){
      //res2 = rho_abs(res1);
      res3 = psi_abs(res1);
      res4 = deriv_psi_abs(res1);
    }else if(loss == "Huber"){
      //res2 = rho_huber(res1, c);
      res3 = psi_huber(res1, c);
      res4 = deriv_psi_huber(res1, c);
    }else if(loss == "Tukey"){
      //res2 = rho_tukey(res1, c);
      res3 = psi_tukey(res1, c);
      res4 = deriv_psi_tukey(res1, c);
    }  
    k1   = k1 + dot(res3, res3); 
    k2   = k2 + dot(res4, res4);   
  }
  if(k1 > tol)      k1 = k1/N;
  else              k1 = tol;
  if(k2 > tol)      k2 = k2/N;
  else              k2 = tol;
  if(loss == "LS")  k3 = 1;
  else              k3 = k1/k2;  
  return(k3);  
}

double raic(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, 
           arma::vec beta, double sigma, double phi, arma::mat Psi, std::string loss, std::string cor,
           double c, double k1, double k2, double tol){
  int P = 0;
  double RAIC =0;
  double sum1 = 0;
  double pi = 3.14159265359; 
  arma::vec res(N);
  res.zeros(); 
  double ldet = 0;
  int a;
  int b;
  int nk = nj.max();
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::mat R1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk);   
  if(cor=="Ind"){
    P = d + 1 + q + l;
  } else {
    P = d + 2 + q + l; 
  }
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(cor=="Ind"){
      R1 = diag_s(pow(sigma,2), nk);
    } else {
      R1 = pow(sigma,2) * ar1(phi, nk); 
    }
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = z1 * Psi * trans(z1) + R1;
    ldet = ldet + log_det(V1, tol);
    P1   = Inv_Sqrt(V1, tol);
    res0 = y1 - (x1 * beta); 
    res1 = P1 * res0;
    if(loss=="LS"){
      res2 = rho_abs(res1);
    } else if(loss=="Huber"){
      res2 = rho_huber(res1, c);
    } else if(loss=="Tukey"){
      res2 = rho_tukey(res1, c);
    }
    sum1 = sum1 + accu(res2);
  }
  RAIC = k1*ldet + 2*sum1 + 2*P*k2 + d*n*log(2*pi);
  return(RAIC/N);
}

double k1(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, 
          double tol, double c, arma::vec theta, std::string loss, std::string cor){
  double k1   = 0;
  int a = 0;
  int b = 0;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res3(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);
  if(cor == "AR1")  theta2 = fill_v((d+3), (d+3+q+l), theta);
  else              theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);  
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    if(cor == "AR1")  V1   = z1 * D * trans(z1) +  pow(theta(d),2) * ar1(theta(d+1), nk);
    else              V1   = z1 * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    P1   = Inv_Sqrt(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    if(loss == "LS"){
      res2 = rho_abs(res1);
      res3 = psi_abs(res1);
    }else if(loss == "Huber"){
      res2 = rho_huber(res1, c);
      res3 = psi_huber(res1, c);
    }else if(loss == "Tukey"){
      res2 = rho_tukey(res1, c);
      res3 = psi_tukey(res1, c);
    }  
    k1   = k1 + dot(res1, res3); 
  }
  if(k1 > tol) k1 = k1/N;
  else k1 = tol;
  return(k1);  
}

// [[Rcpp::export]]
double Eta_ind_abs_w(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, arma::vec w, 
                   arma::vec theta){
  double k1 = 1;
  double sum1 = 0;
  double sum2 = 0; 
  double eta  = 0;
  double ldet = 0;
  int a = 0;
  int b = 0;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk);
  arma::vec w1(nk);
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    w1   = fill_v(a, b, w);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_abs(res1);
    res2 = res2 % w1;
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  eta = eta_trunc(k1, sum1, sum2, tol); 
  return(eta);  
}

// [[Rcpp::export]]
double Eta_ar1_abs_w(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, arma::vec w, 
                   arma::vec theta){
  double k1 = 1;
  double sum1 = 0;
  double sum2 = 0; 
  double eta  = 0;
  double ldet = 0;
  double thetad = pow(theta(d),2);
  int a = 0;
  int b = 0;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec w1(nk);
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+3), (d+3+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    w1   = fill_v(a, b, w);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  (thetad * ar1(theta(d+1), nk));
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_abs(res1);
    res2 = res2 % w1;
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  eta = eta_trunc(k1, sum1, sum2, tol); 
  return(eta);  
}

// [[Rcpp::export]]
double Eta_ind_huber_w(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol,  
                     double c, arma::vec w, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec w1(nk);
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    w1   = fill_v(a, b, w);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_huber(res1, c);
    res2 = res2 % w1;
    res4 = deriv_psi_huber(res1, c);
    k1   = k1 + accu(res4); 
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

// [[Rcpp::export]]
double Eta_ar1_huber_w(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                     double c, arma::vec w, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  double thetad = pow(theta(d),2);
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec w1(nk);
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+3), (d+3+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    w1   = fill_v(a, b, w);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  (thetad * ar1(theta(d+1), nk));
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_huber(res1, c);
    res2 = res2 % w1;
    res4 = deriv_psi_huber(res1, c);
    k1   = k1 + accu(res4); 
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

// [[Rcpp::export]]
double Eta_ind_tukey_w(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                     double c, arma::vec w, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec w1(nk);
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+2), (d+2+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    w1   = fill_v(a, b, w);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  diag_s(pow(theta(d),2), nk);
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_tukey(res1, c);
    res2 = res2 % w1;
    res4 = deriv_psi_tukey(res1, c);
    k1   = k1 + accu(res4); 
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

// [[Rcpp::export]]
double Eta_ar1_tukey_w(int n, int N, int d, int q, int l, arma::vec y, arma::mat x, arma::mat z, arma::vec nj, double tol, 
                     double c, arma::vec w, arma::vec theta){
  double sum1 = 0;
  double sum2 = 0; 
  double k1   = 0;
  double eta  = 0;
  double ldet = 0;
  double thetad = pow(theta(d),2);
  int a;
  int b;
  int nk = nj.max();
  arma::mat D(q,q);
  arma::mat x1(nk, d);
  arma::mat z1(nk, q);  
  arma::mat V1(nk, nk);
  arma::mat P1(nk, nk);
  arma::vec y1(nk); 
  arma::vec w1(nk);
  arma::vec res0(nk); 
  arma::vec res1(nk); 
  arma::vec res2(nk); 
  arma::vec res4(nk);
  arma::vec theta1(d);  
  arma::vec theta2(q+l);
  theta1 = fill_v(1, d, theta);  
  theta2 = fill_v((d+3), (d+3+q+l), theta);
  D = theta2cov(theta2, q);
  for(int j=0; j<n; j++){
    nk = nj(j);
    if(j==0){
      a = 1;
      b = nk;  
    } else {
      a = b + 1;
      b = b + nk;
    }
    y1   = fill_v(a, b, y);
    w1   = fill_v(a, b, w);
    x1   = fill_M(a, b, 1, d, x);
    z1   = fill_M(a, b, 1, q, z);
    V1   = (z1) * D * trans(z1) +  (thetad * ar1(theta(d+1), nk));
    P1   = Inv_Sqrt(V1, tol);
    ldet = log_det(V1, tol);
    res0 = y1 - (x1 * theta1); 
    res1 = P1 * res0;
    res2 = rho_tukey(res1, c);
    res2 = res2 % w1;
    res4 = deriv_psi_tukey(res1, c);
    k1   = k1 + accu(res4); 
    sum1 = sum1 + ldet;
    sum2 = sum2 + dot(res2, res2); 
  }
  if(k1 > tol) k1 = k1/N; 
  else         k1 = tol; 
  eta = eta_trunc(k1, sum1, sum2, tol);   
  return(eta);  
}

